import { Component } from '@shared/component/Component'

export class CurrentPlayerComponent extends Component {
  constructor(entityId: number) {
    super(entityId)
  }
}
